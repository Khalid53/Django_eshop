from django.shortcuts import render, redirect
from store.models.product import Product
from django.views import View


# Create your views here.
class Cart(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        ids = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(ids)
        print(products)
        return render(request, 'cart.html', {'products': products})


def logout(request):
    request.session.clear()
    return redirect('login')
