from django.shortcuts import render, redirect
from store.models.product import Product
from store.models.customer import Customer
from django.views import View
from store.models.orders import Order


# Create your views here.
class Checkout(View):
    def post(self, request):
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        print(address, phone, customer, cart, products)

        for product in products:
            print(cart.get(str(product.id)))
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          phone=phone,
                          address=address,
                          quantity=cart.get(str(product.id)),
                          )
            order.save()
        request.session['cart'] = {}

        return redirect('cart')

