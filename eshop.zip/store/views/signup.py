from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password, check_password
from store.models.product import Product
from store.models.category import Category
from store.models.customer import Customer
from django.views import View

# Create your views here.

class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')
    def post(self, request):
        postData = request.POST
        firstName = postData.get('firstName')
        lastName = postData.get('lastName')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        # validation
        value = {
            'firstName': firstName,
            'lastName': lastName,
            'phone': phone,
            'email': email,
        }
        error_message = None
        customer = Customer(
            firstName=firstName,
            lastName=lastName,
            phone=phone,
            email=email,
            password=password
        )

        if not firstName:
            error_message = "First name required !!"
        elif len(firstName) < 2:
            error_message = 'First name must be 4 char long or more'
        elif not lastName:
            error_message = 'Last name required !!'
        elif len(lastName) < 2:
            error_message = 'last name must be 4 char long or more'
        elif len(phone) < 10:
            error_message = 'Phone number must be 10 char long'
        elif len(password) < 4:
            error_message = 'Password must be 6 char long'
        elif len(email) < 2:
            error_message = 'Email must be 5 char long'
        elif customer.isExists():
            error_message = 'Email address already registered !!'

        # saving
        if not error_message:
            print(firstName, lastName, phone, email, password)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            return render(request, 'signup.html', {'error': error_message, 'values': value})